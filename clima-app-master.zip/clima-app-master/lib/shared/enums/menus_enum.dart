enum OptionMenusEnum { buletin, sixMouth }
